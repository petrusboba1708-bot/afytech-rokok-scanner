package com.afytech.rokokscanner

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.Barcode
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var txtLast: TextView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var lastSavedCode: String? = null
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) startCamera() else Toast.makeText(this, "Izin kamera ditolak", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.previewView)
        txtLast = findViewById(R.id.txtLast)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else { requestPermissionLauncher.launch(Manifest.permission.CAMERA) }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()

            val scannerOptions = BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build()
            val scanner = BarcodeScanning.getClient(scannerOptions)

            analysis.setAnalyzer(cameraExecutor) { imageProxy -> processImageProxy(scanner, imageProxy) }
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, analysis)
            } catch (exc: Exception) {
                Toast.makeText(this, "Gagal mengaktifkan kamera: ${exc.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun processImageProxy(scanner: com.google.mlkit.vision.barcode.BarcodeScanner, imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            scanner.process(image).addOnSuccessListener { barcodes ->
                for (barcode in barcodes) handleCode(barcode.rawValue ?: continue)
            }.addOnFailureListener { }.addOnCompleteListener { imageProxy.close() }
        } else imageProxy.close()
    }

    private fun handleCode(raw: String) {
        if (raw == lastSavedCode) return
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 6) return
        val week = digits.substring(2, 4).toIntOrNull()
        val year = ("20" + digits.takeLast(2)).toIntOrNull()
        if (week == null || year == null) return

        val now = dateFmt.format(java.util.Date())
        val line = "$raw,$week,$year,$now\n"
        val uri = appendCsvToDownloads("rokok_scans.csv", line)
        lastSavedCode = raw
        runOnUiThread {
            txtLast.text = "Terakhir: kode=$raw | minggu=$week | tahun=$year"
            beep(); vibrate()
            Toast.makeText(this, "Tersimpan (${uri?.lastPathSegment})", Toast.LENGTH_SHORT).show()
        }
    }

    private fun appendCsvToDownloads(fileName: String, line: String): Uri? {
        val resolver = contentResolver
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        var existingUri: Uri? = null
        resolver.query(collection, arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME),
            "${MediaStore.Downloads.DISPLAY_NAME}=?", arrayOf(fileName), null)?.use { c ->
            if (c.moveToFirst()) { val id = c.getLong(0); existingUri = Uri.withAppendedPath(collection, id.toString()) }
        }
        val uri = existingUri ?: resolver.insert(collection, ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName); put(MediaStore.Downloads.MIME_TYPE, "text/csv")
        })
        uri?.let {
            resolver.openOutputStream(it, if (existingUri != null) "wa" else "w")?.use { os: OutputStream ->
                if (existingUri == null) os.write("kode,minggu_ke,tahun,waktu_scan\n".toByteArray())
                os.write(line.toByteArray())
                os.flush()
            }
        }
        return uri
    }

    private fun beep() { try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 120) } catch (_: Exception) {} }
    private fun vibrate() {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) v.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") v.vibrate(80)
        } catch (_: Exception) {}
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown() }
}