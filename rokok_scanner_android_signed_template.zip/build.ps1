@echo off
gradlew.bat :app:assembleDebug
echo APK => app\build\outputs\apk\debug\app-debug.apk
