# Build APK
- Debug APK: `./gradlew :app:assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`
- Release (signed):
  1. `keytool -genkeypair -v -keystore my-release-key.keystore -alias rokok -keyalg RSA -keysize 2048 -validity 36500`
  2. Buat `signing.properties` di root:
     ```
     storeFile=my-release-key.keystore
     storePassword=ISI_PASSWORD_KESTORE
     keyAlias=rokok
     keyPassword=ISI_PASSWORD_ALIAS
     ```
  3. `./gradlew :app:assembleRelease` → `app/build/outputs/apk/release/app-release.apk`